﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clase07;

namespace TextWF08
{
    public partial class Form1 : Form
    {
        Paleta _miPaleta;
        public Form1()
        {
            InitializeComponent();
            this._miPaleta = 5;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmTempera frm = new FrmTempera();
            DialogResult rta = frm.ShowDialog();
            if(rta == DialogResult.OK)
            {
                this._miPaleta += frm.MiTempera;
                this.textBox1.Text = (string)this._miPaleta;
            }
            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string texto = this.textBox1.SelectedText;
            int index = 0;
            foreach(string item in this.textBox1.Lines)
            {
                if(texto == item)
                {
                    break;
                }
                index++;
            }
            index = (index - 2) / 2;
            FrmTempera frm = new FrmTempera(this._miPaleta[index]);
        }

        private void agregarPaletaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.groupBox1.Visible = true;
            this.agregarPaletaToolStripMenuItem.Enabled = false;
        }
    }
}
