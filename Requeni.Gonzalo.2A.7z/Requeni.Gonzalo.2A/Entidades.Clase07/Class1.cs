﻿using System;

namespace Entidades.Clase07
{
    public class Class1
    {
    }
}
